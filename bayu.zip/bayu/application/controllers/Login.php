<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('login');		
	}

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/Dashboard.php */