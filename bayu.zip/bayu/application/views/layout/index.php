<?php require_once '1.php'; ?> 
<?php require_once '2.php'; ?>
<?php require_once '3.php'; ?>
<?php if($content) { $this->load->view($content); } ?>
<?php require_once '4.php'; ?>
<?php require_once '5.php'; ?>
